/**
 **************************************************************************************
 * Function definitions                               
 **************************************************************************************
 **/
 
extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
	#include "port_map.h"
	#include "pin_map.h"
	#include "driver_layer.h"
}

#define CLOCKWISE 0
#define ANTICLOCKWISE 1

// Initialise the door with the corresponding port
// Arguments: none
// Returns: void
Door::Door()
{
	port_map = DOOR_OPEN_CLOSE;
}

// Check to see if the door is open or closed
// Arguments: none
// Returns: 0 if closed, 1 if open
bool Door::ReadDoorPort()
{
	port_value = (DOOR_OPEN_CLOSE_PORT) & port_map;
	return port_value;
}

// Initialise the motor with the corresponding port
// Arguments: none
// Returns: void
Motor::Motor()
{
	port_map = MOTOR_CONTROL;
}

// Set the motor to rotate in the chosen direction
// and start rotating
// Arguments: CLOCKWISE or ANTICLOCKWISE
// Returns: void
void Motor::Rotate(bool direction)
{
	if (direction == CLOCKWISE)
	{
		MOTOR_DIRECTION_PORT &= ~(uint16_t) MOTOR_DIRECTION;  // Set motor direction to clockwise
		MOTOR_CONTROL_PORT |= (uint16_t) MOTOR_CONTROL;   // Turn motor on
	}
	else
	{
		MOTOR_DIRECTION_PORT |= (uint16_t) MOTOR_DIRECTION;  // Set motor direction to anticlockwise
		MOTOR_CONTROL_PORT |= (uint16_t) MOTOR_CONTROL;   // Turn motor on
	}
}

// Stop the motor
// Arguments: none
// Returns: void
void Motor::Stop()
{
	MOTOR_CONTROL_PORT &= ~(uint16_t) MOTOR_CONTROL;  // Turn motor off
}

// Initialise the button with the chosen port
// corresponding to the button type
// Arguments: button type (i.e accept, cancel...)
// Returns: void
Button::Button(uint16_t port)
{
	port_map = port;
}

// Check whether the button is on or off
// Arguments: none
// Returns: button state (1 = on, 0 = off)
bool Button::GetButtonState()
{
	return (GPIOE->IDR) & port_map;
}

// Display the chosen digit on the
// 7 segment display
// Arguments: digit to be displayed
// Returns: void
void Display::UpdateDisplay(uint16_t digit)
{
	DISPLAY_PORT |= (uint16_t) digit; 
}

// Convert the number to be shown on the
// display to the corresponding combination
// of segments A, B, C and D
// Arguments: number to be converted and displayed
// Returns: void
void Display::DisplayNumber(int number)
{
	// clear the previous display
	DISPLAY_PORT &= ~((uint16_t) (DISPLAY_A | DISPLAY_B | DISPLAY_C | DISPLAY_D));
	// Initialise the decoded_number to 0x0000
	uint16_t decoded_number = 0x0000; 
		if (number < 10)
		{
			if (number >= 8) // Check whether to set MSB to 1
				{
				decoded_number |= DISPLAY_D; 
				number -= 8;
				}
			if (number >= 4) // Check whether to set second MSB to 1
				{
				decoded_number |= DISPLAY_C;
				number -= 4;
				}
			if (number >= 2) // Check whether to set 3rd MSB to 1
				{
				decoded_number |= DISPLAY_B;
				number -= 2;
				}
			if (number >= 1) // Check whether to set LSB to 1
				{
				decoded_number |= DISPLAY_A;
				number -= 1;
				}
		}
		else
		{
				// not a valid number - clear the display
				decoded_number |= DISPLAY_A | DISPLAY_B | DISPLAY_C | DISPLAY_D;
		}
		// write the decoded number to the display
		UpdateDisplay(decoded_number);
}

// Sound the buzzer for a short time
// Arguments: none
// Returns: void
void Buzzer::SoundBuzzer()
{
		BUZZER_PORT ^= (uint16_t) 0x0040;   // toggle buzzer on
		Timer().Delay(DELAY/2);
		BUZZER_PORT ^= (uint16_t) 0x0040;   // toggle buzzer off after short time
		Timer().Delay(DELAY/2);
}
void Buzzer::DisableBuzzer()
{
	BUZZER_PORT &= (uint16_t) ~(0x0040);
	Timer().Delay(DELAY/2);
}
// Return the time elapsed since the timer was initialised
// Arguments: none
// Returns: time passed since timer started
int Timer::GetTimeCount()
{
	return time_count;
}

// Set the timer to count in seconds
// Arguments: time in s
// Returns: void
void Timer::SetTimeCount(int time)
{
	time_count = time*1000;
}


// Delay for a time given in ms using appropriate millisecond delay function
// Arguments: time in ms
// Returns: none
void Timer::Delay(uint16_t time){
	DELAYER(time);
	time_count-=time;
}
