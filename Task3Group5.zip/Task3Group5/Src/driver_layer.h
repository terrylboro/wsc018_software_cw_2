/**
 ***************************************************************************************
 * Define classes corresponding to each physical component
 * In addition, the timer class which will be used to time
 * processes in task 3
 ***************************************************************************************
 **/

#define DELAY 1000

class Door
{
	public:
		Door();
		bool ReadDoorPort();
	private:
		uint16_t port_map; // port location
		bool port_value; // stores whether door is open or closed
};

class Motor
{
	public:
		Motor();
		void Rotate(bool direction);
		void Stop();
	private:
		uint16_t port_map; // port location
		bool direction; // stores direction motor is spinning
};

class Button
{
	public:
		Button(uint16_t port);
		bool GetButtonState();
	private:
		uint16_t port_map; // port location
		bool state; // stores whether button is being pressed or not
};

class Display
{
	public:
		void UpdateDisplay(uint16_t digit);
		void DisplayNumber(int number);
	private:
		uint16_t port_map; // port location
		bool port_value; // digit displayed
};

class Buzzer
{
	public:
		void SoundBuzzer();
		void DisableBuzzer();
	private:
		uint16_t port_map; // port location
};

class Timer
{
	public:
		int GetTimeCount(void);
		void SetTimeCount(int time = 1); // set default timer to 1 second
		void Delay(uint16_t time = DELAY); // set default delay time to that defined at the top of the program
	private:
		int time_count; // stores the current count on the timer
};
